//==================================================================================
//PROGRAMMER 1:     Angie Martinez
//
//
//PROJECT:          This project encapsulates all that was learned from the course 
//                  finding Nash Equilibrium, and calculating the expected payoffs 
//                  for each player, and more.
//
//==================================================================================
package app;

import java.text.DecimalFormat;
import java.util.Scanner;
import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.*;
import java.util.stream.Collectors;

/**
 *
 * @author angiemartinez
 */
public class Controller {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        
        // to ask for user input
        Scanner scan = new Scanner(System.in);
        
        // ask user for the input
        System.out.print("Enter (R)andom or (M)anual payoff entries: ");
        char chooseMode = scan.next().toUpperCase().charAt(0);
        
        System.out.print("Enter the number of rows: ");
        int rows = scan.nextInt();
        
        System.out.print("Enter the number of columns: ");
        int cols = scan.nextInt();
        
        // upon user selection of either R = random or M = manual
        if(chooseMode == 'R'){
            
            System.out.println();
           
            //===============================================
            // display the strategies for player 1
            //===============================================
            displayPlayerStrategies('A', "Player1", rows);
            
            //===============================================
            // create the random payoffs for player 1
            //===============================================
            int[][] player1Payoffs = createRandomPayoffs(rows, cols);
            displayPlayerPayoffs(player1Payoffs, "Player1");
            
            //===============================================
            // display the strategies for player 2
            //===============================================
            displayPlayerStrategies('B', "Player2", cols);
            
            //===============================================
            // create the random payoffs for player 2
            //===============================================
            int[][] player2Payoffs = createRandomPayoffs(rows, cols);
            displayPlayerPayoffs(player2Payoffs, "Player2");
            
            //===============================================
            // display the normal form table for both players
            //===============================================
            displayNormalForm(player1Payoffs, player2Payoffs);
            
            //===============================================
            // spacer
            //===============================================
            System.out.println();
            
            //=============================================================
            // determining if the normal game contains Nash Equilibrium
            //=============================================================
            boolean[][] isNashEquilibrium = findNashEquilibrium(player1Payoffs, player2Payoffs);
            
            //=============================================================
            // display the normal form again for the Nash Equilibrium
            //=============================================================
            displayNashNormalForm(player1Payoffs, player2Payoffs, isNashEquilibrium);
            
            //===============================================
            // create random beliefs for both players
            //===============================================
            double[] player1Belief = createRandomBeliefs(rows);
            double[] player2Belief = createRandomBeliefs(cols);
           
            System.out.println();
            
            //===============================================
            // display the expected payoffs for each player
            //===============================================
            
            //===============================================
            // for player 1
            //===============================================
            displayExpectedPayoffs(player1Payoffs, player2Belief, "Player 1", "Player 2");
            
            //===============================================
            // display the best response for player 1
            //===============================================
            displayBestResponse(player1Payoffs, player2Belief, "Player 1", "Player 2");
            
            //===============================================
            //for player 2
            //===============================================
            displayExpectedPayoffs(player2Payoffs, player1Belief, "Player 2", "Player 1");
            
            //===============================================
            // display the best response for player 1
            //===============================================
            displayBestResponse(player2Payoffs, player1Belief, "Player 2", "Player 1");
            
            //===================================================================
            // display expected payoffs for both players with their actual mix
            //===================================================================
            displayExpectedPayoffsForBothPlayers(player1Payoffs, player2Payoffs, player1Belief, player2Belief);
            
            //===========================================================
            // calculating the indifference probabilities if 2x2 matrix
            // + no pure Nash Equilibrium
            //===========================================================
            if (rows == 2 && cols == 2 && !hasPureNashEquilibrium(player1Payoffs, player2Payoffs)) {
                System.out.println("\n-------------------------------------------");
                System.out.println("Player 1 & 2 Indifferent Mix Probabilities");
                System.out.println("-------------------------------------------");

                double pA1 = calculateIndifferenceProbability(player1Payoffs, player2Payoffs, 0, 0);
                double pA2 = 1.0 - pA1;
                double pB1 = calculateIndifferenceProbability(player2Payoffs, player1Payoffs, 0, 0);
                double pB2 = 1.0 - pB1;

                System.out.printf("Player 1 probability of strategies (A1) = %.2f%n", pA1);
                System.out.printf("Player 1 probability of strategies (A2) = %.2f%n", pA2);
                System.out.printf("Player 2 probability of strategies (B1) = %.2f%n", pB1);
                System.out.printf("Player 2 probability of strategies (B2) = %.2f%n", pB2);
                
                System.out.println();
                
                displayNashNormalForm(player1Payoffs, player2Payoffs, isNashEquilibrium);
                
            } else {
                
                System.out.println("\n");
                
                displayNashNormalForm(player1Payoffs, player2Payoffs, isNashEquilibrium);
                
                System.out.println("\n-------------------------------------------");
                System.out.println("Player 1 & 2 Indifferent Mix Probabilities");
                System.out.println("-------------------------------------------");
                System.out.println("Normal Form has Pure Strategy Equilibrium");
                
            }//end if-else statement
          
        } else if(chooseMode == 'M'){
            System.out.println("\nManual Entries");
            
            int[][] player1Payoffs = new int[rows][cols];
            int[][] player2Payoffs = new int[rows][cols];
            
            // get manual input for player 1 and player 2 payoffs
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    
                    boolean validInput = false;
                    
                    while (!validInput) {
                        
                        System.out.printf("Enter payoff for (A%d, B%d): ", i + 1, j + 1);
                        String input = scan.next();

                        // Check if the input contains a comma and is followed by an integer
                        if (input.contains(",") && input.split(",").length == 2) {
                            String[] coordinates = input.split(",");
                            try {
                                player1Payoffs[i][j] = Integer.parseInt(coordinates[0]);
                                player2Payoffs[i][j] = Integer.parseInt(coordinates[1]);
                                validInput = true;
                            } catch (NumberFormatException e) {
                                System.out.println("Invalid input. Please enter valid integers.");
                            }
                        } else {
                            System.out.println("Invalid input format. Please use 'x,y' format.");
                        }
                    }
                }
                
                System.out.println("-------------------------");
            }
            
            
            // Display the entered payoffs for verification
            displayPlayerPayoffs(player1Payoffs, "Player1");
            displayPlayerPayoffs(player2Payoffs, "Player2");
            
            
            // display the normal form for manual mode
            displayNormalForm(player1Payoffs, player2Payoffs);
            
            // find the Nash Equilibrium for manual mode
            boolean[][] isNashEquilibrium = findNashEquilibrium(player1Payoffs, player2Payoffs);
            
            // display the Nash Equilibrium for the normal form game
            displayNashNormalForm(player1Payoffs, player2Payoffs, isNashEquilibrium);
            
            // calculate indifference for 2x2 matrix and no Pure Nash Equilibrium
            if (rows == 2 && cols == 2 && !hasPureNashEquilibrium(player1Payoffs, player2Payoffs)) {
                
                System.out.println("\n-------------------------------------------");
                System.out.println("Player 1 & 2 Indifferent Mix Probabilities");
                System.out.println("-------------------------------------------");

                double pA1 = calculateIndifferenceProbability(player1Payoffs, player2Payoffs, 0, 0);
                double pA2 = 1.0 - pA1;
                double pB1 = calculateIndifferenceProbability(player2Payoffs, player1Payoffs, 0, 0);
                double pB2 = 1.0 - pB1;

                System.out.printf("Player 1 probability of strategies (A1) = %.2f%n", pA1);
                System.out.printf("Player 1 probability of strategies (A2) = %.2f%n", pA2);
                System.out.printf("Player 2 probability of strategies (B1) = %.2f%n", pB1);
                System.out.printf("Player 2 probability of strategies (B2) = %.2f%n", pB2);
                
                System.out.println();
                
                displayNashNormalForm(player1Payoffs, player2Payoffs, isNashEquilibrium);
                
            } else {
                
                System.out.println("\n");
                
                displayNashNormalForm(player1Payoffs, player2Payoffs, isNashEquilibrium);
                
                System.out.println("\n-------------------------------------------");
                System.out.println("Player 1 & 2 Indifferent Mix Probabilities");
                System.out.println("-------------------------------------------");
                System.out.println("Normal Form has Pure Strategy Equilibrium");
                
            }//end if-else statement
            
        }//end outer if-else statement (chooseMode)
  
    }//end main
    
    
    //=====================================
    // Displaying Player's Strategies
    //=====================================
     private static void displayPlayerStrategies(char player, String playerName, int numStrategies) {
         
        System.out.println("-----------------------------\n"
                + "Player: "+ playerName + "'s strategies"
                        + "\n-----------------------------");
        
        System.out.print("{");
        
        for (int i = 1; i <= numStrategies; i++) {
            System.out.print(player + String.valueOf(i));
            if (i < numStrategies) {
                System.out.print(", ");
            }
        }
        
        System.out.println("}\n");
        
    }//end displayPlayerstrategies

    //=====================================
    // Displaying Player's Random Payoffs
    //=====================================
    private static void displayPlayerPayoffs(int[][] payoffs, String playerName) {
        
        System.out.println("-----------------------------\n"
                + "Player: "+playerName+"'s payoffs"
                        + "\n-----------------------------");
        
        for (int i = 0; i < payoffs.length; i++) {
            for (int j = 0; j < payoffs[i].length; j++) {
                System.out.printf("%4d", payoffs[i][j]);
                if (j < payoffs[i].length - 1) {
                    System.out.print(", ");
                }
            }
            System.out.println();
        }
        
        System.out.println();
        
    }//end displayPlayerPayoffs

    //================================
    // Creating Random Payoffs
    //================================
    private static int[][] createRandomPayoffs(int numRows, int numCols) {
        
        int[][] payoffs = new int[numRows][numCols];
        
        Random random = new Random();

        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                // generate random integers from -99 to 99
                payoffs[i][j] = random.nextInt(199) - 99; 
            }
        }

        return payoffs;
        
    }//end generateRandomPayoffs

    //=======================================
    // Helper: Creating a Horizontal Line
    //=======================================
    private static void displayHorizontalLine(int cols) {
        System.out.println("\n" + " ".repeat(4) + "---".repeat(4 * cols));
        
    }//end displayHorizontalLine

    //================================
    // Displaying the Normal Form
    //================================
    private static void displayNormalForm(int[][] player1Payoffs, int[][] player2Payoffs) {
        
        int rows = player1Payoffs.length;
        int cols = player2Payoffs[0].length;
        
        System.out.println("=======================================");
        System.out.println("Display Normal Form");
        System.out.println("=======================================\n");

        // display column headers
        System.out.print("  ");
        for (int j = 1; j <= player1Payoffs[0].length; j++) {
            System.out.printf("%11.9s", "B" + j);
        }
        displayHorizontalLine(cols);

        // display matrix content
        for (int i = 0; i < player1Payoffs.length; i++) {
            System.out.printf("A%d | ", (i + 1));
            for (int j = 0; j < player1Payoffs[i].length; j++) {
                System.out.printf("(%3d,%3d) | ", player1Payoffs[i][j], player2Payoffs[i][j]);
            }
            displayHorizontalLine(cols);
        }
        
    }//end displayNormalForm
    
    //===============================================
    // Displaying the Nash Equilibrium Normal Form
    //===============================================
    private static void displayNashNormalForm(int[][] player1Payoffs, int[][] player2Payoffs, boolean[][] isNashEquilibrium) {
        
        int rows = player1Payoffs.length;
        int cols = player2Payoffs[0].length;
        
        System.out.println("=======================================");
        System.out.println("Nash Pure Equilibrium Locations");
        System.out.println("=======================================\n");

        // display column headers
        System.out.print("  ");
        for (int j = 1; j <= player1Payoffs[0].length; j++) {
            System.out.printf("%11.9s", "B" + j);
        }
        
        displayHorizontalLine(cols);

        // display matrix content
        for (int i = 0; i < player1Payoffs.length; i++) {
            System.out.printf("A%d | ", (i + 1));
            for (int j = 0; j < player1Payoffs[i].length; j++) {

                if (isNashEquilibrium[i][j]) {
                    System.out.print("( H, H ) | ");
                } else {
                    System.out.printf("(%3d,%3d) | ", player1Payoffs[i][j], player2Payoffs[i][j]);
                }
            }
            displayHorizontalLine(cols);
        }

        // display the Nash Equilibrium table
        displayNashEquilibrium(isNashEquilibrium);
        
    }//end displayNashNormalForm
    
    //================================
    // Finding Nash Equilibrium
    //================================
    private static boolean[][] findNashEquilibrium(int[][] player1Payoffs, int[][] player2Payoffs) {
        
        int numRows = player1Payoffs.length;
        int numCols = player1Payoffs[0].length;
        
        boolean[][] isNashEquilibrium = new boolean[numRows][numCols];

        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                int player1Payoff = player1Payoffs[i][j];
                int player2Payoff = player2Payoffs[i][j];

                // check if (i, j) is a Nash Equilibrium
                isNashEquilibrium[i][j] = isBestResponse(player1Payoffs, player2Payoffs, i, j, player1Payoff, player2Payoff);
            }
        }

        return isNashEquilibrium;
        
    }// end findNashEquilibrium
    
    //================================
    // Is Best Response
    //================================
    private static boolean isBestResponse(int[][] player1Payoffs, int[][] player2Payoffs,
                                          int row, int col, int player1Payoff, int player2Payoff) {
        
        for (int k = 0; k < player1Payoffs.length; k++) {
            if (player1Payoffs[k][col] > player1Payoff) {
                // (row, col) is not a best response for player 1
                return false; 
            }
        }

        for (int k = 0; k < player2Payoffs[0].length; k++) {
            if (player2Payoffs[row][k] > player2Payoff) {
                // (row, col) is not a best response for player 2
                return false; 
            }
        }

        // (row, col) is a Nash Equilibrium
        return true;
        
    }//end isBestResponse
    
    //================================
    // Display Nash Equilibrium
    //================================
    private static void displayNashEquilibrium(boolean[][] isNashEquilibrium) {
        
        System.out.print("Nash Pure Equilibrium(s): ");
        
        boolean noEquilibrium = true;

        for (int i = 0; i < isNashEquilibrium.length; i++) {
            for (int j = 0; j < isNashEquilibrium[i].length; j++) {
                if (isNashEquilibrium[i][j]) {
                    System.out.printf("(%s, %s) ", "A" + (i + 1), "B" + (j + 1));
                    noEquilibrium = false;
                }
            }
        }

        if (noEquilibrium) {
            System.out.println("None");
        } else {
            System.out.println();
        }
        
    }//end displayNashEquilibirum
    
    
    //================================
    // Creating Random Beliefs
    //================================
    private static double[] createRandomBeliefs(int numBeliefs) {
        
        Random random = new Random();
        
        double[] beliefs = new double[numBeliefs];

        double sum = 0.0;
        
        for (int i = 0; i < numBeliefs - 1; i++) {
            beliefs[i] = random.nextDouble();
            // Ensure non-negative values
            beliefs[i] = Math.max(0, beliefs[i]);
            sum += beliefs[i];
        }

        beliefs[numBeliefs - 1] = Math.max(0, 1.0 - sum);

        return beliefs;
        
    }//end createRandomBeliefs


    //=================================================
    // Calculating Expected Payoffs for each Player
    //=================================================
    private static double calculateExpectedPayoffPlayer(int action, int[][] payoffs, double[] beliefsPlayer2) {
        
        double expectedPayoff = 0.0;
        
        for (int i = 0; i < beliefsPlayer2.length; i++) {
            expectedPayoff += beliefsPlayer2[i] * payoffs[action][i];
        }
        return expectedPayoff;
        
    }//end calculateExpectedPayoffPlayer

    //=================================================
    // Calculating Best Responses for each Player
    //=================================================
    private static int calculateBestResponsePlayer(int[][] payoffs, double[] beliefsPlayer2) {
        
        double maxExpectedPayoff = Double.NEGATIVE_INFINITY;
        
        int bestResponse = -1;

        for (int i = 0; i < payoffs.length; i++) {
            double expectedPayoff = calculateExpectedPayoffPlayer(i, payoffs, beliefsPlayer2);
            if (expectedPayoff > maxExpectedPayoff) {
                maxExpectedPayoff = expectedPayoff;
                bestResponse = i;
            }
        }

        return bestResponse;
        
    }//end calculateBestResponsePlayer
    
    //=================================================
    // Display Expected Payoffs for each Player
    //=================================================
    private static void displayExpectedPayoffs(int[][] payoffs, double[] beliefs, String player, String opponent) {
        
        System.out.println("\n-------------------------------------------------------");
        System.out.println(player + " Expected Payoffs with " + opponent + " Mixing");
        System.out.println("-------------------------------------------------------");

        for (int i = 0; i < payoffs.length; i++) {
            double expectedPayoff = calculateExpectedPayoffPlayer(i, payoffs, beliefs);

            System.out.printf("U(%s%d, (", (player.equals("Player 1") ? "A" : ""), (i + 1));

            for (int j = 0; j < beliefs.length; j++) {
                System.out.printf("%.2f", beliefs[j]);

                if (j < beliefs.length - 1) {
                    System.out.print(", ");
                }
            }

            System.out.printf(")) = %.2f%n", expectedPayoff);
        }
        
    }//end displayExpectedPayoffs


    //=================================================
    // Display Best Responses for each Player
    //=================================================
    private static void displayBestResponse(int[][] payoffs, double[] beliefs, String player, String opponent) {
        
        System.out.println("\n-------------------------------------------------------");
        System.out.println(player + " Best Response with " + opponent + " Mixing");
        System.out.println("-------------------------------------------------------");

        int bestResponse = calculateBestResponsePlayer(payoffs, beliefs);

        // Use DecimalFormat to format the output with two decimal places
        DecimalFormat df = new DecimalFormat("#.##");
        
        System.out.printf("BR%s = {%s%s}%n", Arrays.toString(Arrays.stream(beliefs).mapToObj(df::format).toArray()), 
                (player.equals("Player 1") ? "A" : "B"), bestResponse + 1);
        
    }//end displayBestResponse
    
    //=================================================
    // Display Expected Payoffs for both Players
    //=================================================
    private static void displayExpectedPayoffsForBothPlayers(int[][] player1Payoffs, int[][] player2Payoffs, double[] beliefsPlayer1, double[] beliefsPlayer2) {
        
        System.out.println("\n-------------------------------------------------------");
        System.out.println("Player 1 & 2 Expected Payoffs with both Players Mixing");
        System.out.println("-------------------------------------------------------");

        double expectedPayoffPlayer1 = calculateExpectedPayoffPlayerWithMix(player1Payoffs, beliefsPlayer1, beliefsPlayer2);
        double expectedPayoffPlayer2 = calculateExpectedPayoffPlayerWithMix(player2Payoffs, beliefsPlayer2, beliefsPlayer1);

        System.out.printf("Player 1 -> U(");
        displayBeliefs(beliefsPlayer1);
        System.out.printf(", ");
        displayBeliefs(beliefsPlayer2);
        System.out.printf(") = %.2f%n", expectedPayoffPlayer1);

        System.out.printf("Player 2 -> U(");
        displayBeliefs(beliefsPlayer1);
        System.out.printf(", ");
        displayBeliefs(beliefsPlayer2);
        System.out.printf(") = %.2f%n", expectedPayoffPlayer2);
        
    }//end displayExpectedPayoffsForBothPlayers

    //=================================================
    // Display Beliefs for each Player
    //=================================================
    private static void displayBeliefs(double[] beliefs) {
       
        System.out.print("(");
        
        for (int i = 0; i < beliefs.length; i++) {
            System.out.printf("%.2f", beliefs[i]);

            if (i < beliefs.length - 1) {
                System.out.print(", ");
            }
        }
        
        System.out.print(")");
        
    }//end displayBeliefs

    //===================================================================
    // Calculating Expected Payoffs for each Player with Mixed Payoffs
    //===================================================================
    private static double calculateExpectedPayoffPlayerWithMix(int[][] payoffs, double[] beliefsPlayer, double[] beliefsOpponent) {
        
        double expectedPayoff = 0.0;

        // Ensure loop bounds are based on the minimum length between beliefsPlayer and payoffs
        int minBeliefsLength = Math.min(beliefsPlayer.length, payoffs.length);
        
        for (int i = 0; i < minBeliefsLength; i++) {
            // Ensure loop bounds are based on the minimum length between beliefsOpponent and payoffs[0]
            int minOpponentLength = Math.min(beliefsOpponent.length, payoffs[0].length);
            for (int j = 0; j < minOpponentLength; j++) {
                expectedPayoff += beliefsPlayer[i] * beliefsOpponent[j] * payoffs[i][j];
            }
        }

        return expectedPayoff;
        
    }//end calculateExpectedPayoffPlayerWithMix

   
    //===================================================================
    // Determining if a Game has a Pure Nash Equilibrium
    //===================================================================
    private static boolean hasPureNashEquilibrium(int[][] player1Payoffs, int[][] player2Payoffs) {
        boolean[][] isNashEquilibrium = findNashEquilibrium(player1Payoffs, player2Payoffs);
        for (boolean[] row : isNashEquilibrium) {
            for (boolean value : row) {
                if (value) {
                    return true;
                }
            }
        }
        return false;
        
    }//end hasPureNashEquilibrium
    
    
    //=============================================
    // Calculating the Indifference Probability 
    //=============================================
    private static double calculateIndifferenceProbability(int[][] payoffs1, int[][] payoffs2, int row, int col) {
        int diff = payoffs1[row][col] - payoffs1[1 - row][col];
        return 1.0 / (1 + Math.exp(-diff));
        
    }//end calculateIndifferenceProbability
    
}//end Controller
